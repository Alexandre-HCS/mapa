<?php $__env->startSection('title', $location->name . ' - Laravel Maps App'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1><i class="fas fa-map-marker-alt me-2"></i><?php echo e($location->name); ?></h1>
            <div>
                <a href="<?php echo e(route('locations.edit', $location->id)); ?>" class="btn btn-warning me-2"><i class="fas fa-edit"></i> Editar</a>
                <a href="<?php echo e(route('locations.index')); ?>" class="btn btn-outline-secondary"><i class="fas fa-arrow-left"></i> Voltar</a>
            </div>
        </div>
    </div>
</div>
</div>

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-map me-2"></i>Localização no mapa
                </h5>
            </div>
            <div class="card-body">
                <div id="map" style="height: 400px;"></div>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-info-circle me-2"></i>Informações do Local
                </h5>
            </div>
            <div class="card-body">
                <div class="mb3">
                    <label class="form-label fw-bold">Nome: </label>
                    <p class="mb-0"><?php echo e($location->name); ?></p>
                </div>

                <?php if($location->category): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Categoria:</label>
                    <p class="mb-0">
                        <span class="badge bg-secondary"><?php echo e($location->category); ?></span>
                    </p>
                </div>
                <?php endif; ?>

                <?php if($location->description): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Descrição:</label>
                    <p class="mb-0"><?php echo e($location->description); ?></p>
                </div>
                <?php endif; ?>

                <?php if($location->address): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Endereço:</label>
                    <p class="mb-0">
                        <i class="fas fa-map-pin me-1"></i><?php echo e($location->address); ?>

                    </p>
                </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label fw-bold">Coordenadas:</label>
                    <p class="mb-0">
                        <i class="fas fa-location-arrow me-1"></i>

                        <?php echo e($location->latitude); ?>, <?php echo e($location->longitude); ?>

                    </p>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold">Data de Criação:</label>
                    <p class="mb-0"><?php echo e($location->created_at->format('d/m/Y H:i')); ?></p>
                </div>

                <?php if($location->updated_at != $location->created_at): ?>
                <div class="mb-3">
                    <label class="form-label fw-bold">Última Atualização:</label>
                    <p class="mb-0"><?php echo e($location->updated_at->format('d/m/Y H:i')); ?></p>
                </div>
                <?php endif; ?>

                <hr>

                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('locations.edit', $location->id)); ?>" class="btn btn-warning"><i class="fas fa-edit"></i> Editar Local</a>
                    <form action="<?php echo e(route('locations.destroy', $location->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
<button type="submit" class="btn btn-danger" onclick="return confirm('Tem certeza que deseja excluir este local?')">
    <i class="fas fa-trash"></i> Deletar Local
</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        var map= L.map('map').setView([<?php echo e($location->latitude); ?>, <?php echo e($location->longitude); ?>], 15);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        var marker = L.marker([<?php echo e($location->latitude); ?>, <?php echo e($location->longitude); ?>]).addTo(map)
            .bindPopup('<?php echo e($location->name); ?>')
            .openPopup(`
            <div class="text-center">
            <h6><strong><?php echo e($location->name); ?></strong></h6>
            <?php if($location->category): ?>
            <p class="badge bg-secondary"><?php echo e($location->category); ?></span></p>
            <?php endif; ?>
            <?php if($location->address): ?>
            <p class="fas fa-map-pin"><?php echo e($location->address); ?></p>
            <?php endif; ?>
            <?php if($location->description): ?>
            <p><?php echo e($location->description); ?></p>
            <?php endif; ?>
            </div>
        `);

        marker.openPopup
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Apache\htdocs\mapa\resources\views/locations/show.blade.php ENDPATH**/ ?>